var mongoose = require('mongoose'), Flat = mongoose.model('Flat');

module.exports ={
    GetAll: function(req,res){
        console.log(" Print all the flat bookings");
        Flat.find({}, function(err, results){
            if(err) throw err;
                res.render('displayflat.ejs', {allthebookings:results});
        }); 
    },

    Create: function(req,res){
        console.log("Booking a new flat...");
        var flatinfo = req.body;
        flatinfo={
            "name" : req.body.name,
            "hno" : req.body.hno,
            "street" : req.body.street,
            "city" : req.body.city,
            "pro" : req.body.pro,
            "code" : req.body.code,
            "noOfParking":req.body.noOfParking,
            "floor":req.body.floor,
            "club":req.body.club
        }
        Flat.create(flatinfo,function(err,result){
            if(err){
                console.log("validation errorrrrrrr")
                return;
            }
            res.redirect('/flats');
        });
    },

    Edit: function(req,res){
        Flat.findById(req.params.id, (err, doc)=>{
            if(err){
                console.log(err);
                res.redirect("/");
            }else{
                res.render("updatebooking.ejs",{product: doc});
            }
        })
    },

    Update: function(req, res){
        Flat.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
            if (!err) { res.redirect('/flats'); }
            else {
                if (err.name == 'ValidationError') {
                    handleValidationError(err, req.body);
                    res.render("Booking/add", { booking: req.body }); 
                }
                else
                    console.log('Error during record update : ' + err);
            }
        });
    },

    Delete: function(req, res){
        Flat.findByIdAndRemove(req.params.id, (err, doc) => {
            if (!err) {
                res.redirect('/flats');
            }
            else{
              console.log('Error in Booking delete :' + err);
            }
        })
    }    
}
