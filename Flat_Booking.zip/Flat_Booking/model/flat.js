const mongoose = require('mongoose')

const flatSchema = new mongoose.Schema({
    
    name:{
        type: String,
        required: [true, 'this field is required']
    },
    hno:{
        type: Number,
        required: [true, 'this field is required']
    },
    street:{
        type: String,
        required: [true, 'this field is required']
    },
    city:{
        type: String,
        required: [true, 'this field is required']
    },
    pro:{
        type: String,
        required: [true, 'this field is required']
    },
    code:{
        type: String,
        required: [true, 'this field is required']
    },
    noOfParking:{
        type: Number,
        required:[true, 'this field is required'],
        min: 0,
        max: 6
    },
    floor:{
        type: Number,
        required:[true, 'this field is required']
    },
    club:{
        type: String,
        required:[true, 'this field is required']
    }

})

module.exports = mongoose.model('Flat', flatSchema)

